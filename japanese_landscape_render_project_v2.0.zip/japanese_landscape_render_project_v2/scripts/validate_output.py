#!/usr/bin/env python3
"""Validate output file format, dimensions, and optional protected-pixel equality."""
import argparse
from PIL import Image, ImageChops
p=argparse.ArgumentParser(); p.add_argument('base'); p.add_argument('result'); p.add_argument('--mask'); a=p.parse_args()
base=Image.open(a.base).convert('RGBA'); result=Image.open(a.result).convert('RGBA')
print(f'result_size={result.width}x{result.height}; format={Image.open(a.result).format}; target_4k={result.size==(3840,2160)}')
if base.size!=result.size: raise SystemExit('FAIL: base/result dimensions differ; geometry comparison not pixel-aligned')
if a.mask:
    mask=Image.open(a.mask).convert('L')
    if mask.size!=base.size: raise SystemExit('FAIL: mask dimensions differ')
    diff=ImageChops.difference(base,result).convert('RGB')
    # Any nonzero diff within protected region is a failure.
    import numpy as np
    import PIL.Image as PI
    m=np.array(mask)>0; d=np.array(diff)
    changed=((d.max(axis=2)>0)&m).sum()
    protected=m.sum()
    print(f'protected_pixels={protected}; changed_protected_pixels={changed}')
    print('protected_pixel_check='+('PASS' if changed==0 else 'FAIL'))
else:
    print('protected_pixel_check=NOT_RUN (no mask supplied)')
