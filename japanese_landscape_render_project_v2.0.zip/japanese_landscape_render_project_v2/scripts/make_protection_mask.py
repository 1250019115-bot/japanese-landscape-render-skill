#!/usr/bin/env python3
"""Create a manual protection mask from normalized polygons in JSON.
White (255) = preserve original pixels; black (0) = use generated image.
"""
import argparse, json
from pathlib import Path
from PIL import Image, ImageDraw
p=argparse.ArgumentParser(); p.add_argument('base_image'); p.add_argument('config'); p.add_argument('-o','--output',default='protection_mask.png'); a=p.parse_args()
with Image.open(a.base_image) as im: w,h=im.size
cfg=json.loads(Path(a.config).read_text(encoding='utf-8'))
mask=Image.new('L',(w,h),0); draw=ImageDraw.Draw(mask)
for region in cfg.get('regions',[]):
    pts=region.get('points',[])
    if len(pts)<3: raise SystemExit(f"Region {region.get('name')} needs >=3 points")
    xy=[]
    for x,y in pts:
        if not (0<=x<=1 and 0<=y<=1): raise SystemExit('Coordinates must be normalized 0..1')
        xy.append((round(x*(w-1)),round(y*(h-1))))
    draw.polygon(xy,fill=255)
mask.save(a.output)
print(f'Saved {a.output} ({w}x{h}); white=preserve original. Inspect mask visually before compositing.')
