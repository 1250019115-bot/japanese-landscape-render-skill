#!/usr/bin/env python3
"""Inspect image dimensions, format, and basic file properties."""
import argparse
from pathlib import Path
from PIL import Image
p=argparse.ArgumentParser(); p.add_argument('image'); a=p.parse_args()
path=Path(a.image)
with Image.open(path) as im:
    print(f'file: {path}')
    print(f'format: {im.format}')
    print(f'mode: {im.mode}')
    print(f'size: {im.width}x{im.height}')
    print(f'aspect_ratio: {im.width/im.height:.5f}')
    print(f'native_4k_16_9: {im.size == (3840,2160)}')
