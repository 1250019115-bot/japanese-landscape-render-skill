#!/usr/bin/env python3
"""Composite generated image while preserving original pixels under white mask."""
import argparse
from PIL import Image
p=argparse.ArgumentParser(); p.add_argument('base'); p.add_argument('generated'); p.add_argument('mask'); p.add_argument('-o','--output',default='protected_composite.png'); a=p.parse_args()
base=Image.open(a.base).convert('RGBA'); gen=Image.open(a.generated).convert('RGBA'); mask=Image.open(a.mask).convert('L')
if gen.size!=base.size: raise SystemExit(f'Image sizes differ: base={base.size}, generated={gen.size}. Align/crop explicitly first; script will not silently resize.')
if mask.size!=base.size: raise SystemExit(f'Mask size {mask.size} differs from base {base.size}')
# Composite mask semantics: white retains original, black takes generated.
out=Image.composite(base,gen,mask)
out.save(a.output)
print(f'Saved {a.output}. White mask pixels retain original base exactly.')
